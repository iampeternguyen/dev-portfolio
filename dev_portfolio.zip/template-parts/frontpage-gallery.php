<div class="projectGallery__section">

  <a href="#projects">
    <h2 id="projects" class="projectGallery__header tooltip red down bottom margin huge">Projects</h2>
  </a>

  <div id="projectGallery" class="projectGallery__container container">
    <?php get_template_part('template-parts/project', 'gallery'); ?>
    <div class="code__tooltip projectGallery__tooltip tooltip left blue" onClick="codeModal.show(26)">Project Gallery
    </div>
  </div>



</div>