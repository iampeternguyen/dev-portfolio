<div id="contact" class="contact__section">
  <div class="contact__container container">
    <h2 class="contact__header bottom margin medium">Want to collaborate on something?</h2>
    <p class="contact__message">Send me a message at <span class="contact__email"><a
          href="mailto:hi@meetpeter.us?Subject=Hello!" target="_top">hi@meetpeter.us</a></span></p>
    <div class="code__tooltip contact__emailTooltip tooltip up blue" onClick="codeModal.show(27)">Email button</div>
  </div>
</div>